# shopper-square
E-Commerce Website

This an ecommerce website which is built using servlet and jsp which makes it database dependent. It is divided into two parts frontend and backend which makes it scalable.

It has a role based access mechanism i.e Customer and Admin and also has a stock managemaent system for products. 
Admin - He will be able to add, delete any of the productr.

Customer -They will be able to browse all the products, perform cart operations ( add a product, remove   product quantity ) and buy as well.

Prerequisites

JDK 1.8
Web Server supporting Servlets

Oracle database
Modern web browser supporting HTML 5, CSS 3 and 
Clone its backend project or else it will not work ! Important

[Shopping website ] https://github.com/kiran/shopper-square

Configuration

Switch to the directory location where you want to clone the repository and type command


Run all the create table queries present in DatabaseQueries.sql file in backend https://github.com/kiran/shopper-square/blob/master/web/Include_Page/DatabaseQuery.sql

4.Add the project to server and run the server. 5. After running server please run following query in h2 console to access admin account with username 'admin' and password 'kirnya@123'.

Technologies used
Servlet
Bootstrap 3
HTML 5
CSS 3


Contributors

All roles were played alone

License

Kiran bhor 